﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace helloworld
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("hello world");
            Console.Read();
        }
    }
}
